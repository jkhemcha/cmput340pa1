% demo for the elimMat.m function
A = [1,-1,0;-1,2,-1;,0,-1,1]
elimMat(A,1)
elimMat(A,2)