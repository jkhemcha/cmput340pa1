% demo for the backSubst function
U = [1,1,1;0,1,1;0,0,1]
y = [6;4;2]

backSubst(A, y)